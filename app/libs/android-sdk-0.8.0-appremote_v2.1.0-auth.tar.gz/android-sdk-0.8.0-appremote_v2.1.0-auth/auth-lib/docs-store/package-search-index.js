packageSearchIndex = [{"l":"All Packages","url":"allpackages-index.html"},{"l":"com.spotify.sdk.android.auth"},{"l":"com.spotify.sdk.android.auth.app"},{"l":"com.spotify.sdk.android.auth.store"}]
